import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, AlertCircle, UploadCloud } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import type { Customer, CustomerInput } from "@/hooks/useCustomers";
import type { Plan } from "@/hooks/usePlans";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer?: Customer | null;
  onSave: (data: CustomerInput) => Promise<boolean>;
  onUpdate?: (id: string, data: Partial<CustomerInput>) => Promise<boolean>;
  plans?: Plan[];
}

const formatCPF = (value: string) => {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  return digits
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
};

const formatPhone = (value: string) => {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length <= 10) {
    return digits.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  }
  return digits.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};

const formatCEP = (value: string) => {
  const digits = value.replace(/\D/g, "").slice(0, 8);
  return digits.replace(/(\d{5})(\d)/, "$1-$2");
};

const formatCurrency = (cents: number) =>
  (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function isValidCPF(cpf: string): boolean {
  const clean = cpf.replace(/\D/g, "");
  if (clean.length !== 11 || /^(\d)\1{10}$/.test(clean)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += parseInt(clean[i]) * (10 - i);
  let rest = (sum * 10) % 11;
  if (rest === 10) rest = 0;
  if (rest !== parseInt(clean[9])) return false;
  sum = 0;
  for (let i = 0; i < 10; i++) sum += parseInt(clean[i]) * (11 - i);
  rest = (sum * 10) % 11;
  if (rest === 10) rest = 0;
  return rest === parseInt(clean[10]);
}

export default function CustomerFormDialog({ open, onOpenChange, customer, onSave, onUpdate, plans = [] }: Props) {
  const [form, setForm] = useState<CustomerInput & { cortesia: boolean }>({
    nome: "", cpf: "", email: "", telefone: "", usuario_pppoe: "", senha_pppoe: "",
    rua: null, numero: null, complemento: null, bairro: null, cidade: null, estado: null, cep: null,
    dia_vencimento: 10, plan_id: null, desconto_especial_centavos: 0, cortesia: false,
    seller_name: null, preferred_payment_method: null, pop_name: null, cancelled_at: null, cancel_reason: null,
  });
  const [saving, setSaving] = useState(false);
  const [sendingMikrotik, setSendingMikrotik] = useState(false);


  useEffect(() => {
    if (customer) {
      setForm({
        nome: customer.nome, cpf: customer.cpf, email: customer.email,
        telefone: customer.telefone || "", usuario_pppoe: customer.usuario_pppoe, senha_pppoe: customer.senha_pppoe,
        rua: customer.rua || null, numero: customer.numero || null, complemento: customer.complemento || null,
        bairro: customer.bairro || null, cidade: customer.cidade || null, estado: customer.estado || null, cep: customer.cep || null,
        dia_vencimento: customer.dia_vencimento, plan_id: customer.plan_id, desconto_especial_centavos: customer.desconto_especial_centavos,
        cortesia: customer.cortesia ?? false,
        seller_name: customer.seller_name, preferred_payment_method: customer.preferred_payment_method,
        pop_name: customer.pop_name, cancelled_at: customer.cancelled_at, cancel_reason: customer.cancel_reason,
      });
    } else {
      setForm({
        nome: "", cpf: "", email: "", telefone: "", usuario_pppoe: "", senha_pppoe: "",
        rua: null, numero: null, complemento: null, bairro: null, cidade: null, estado: null, cep: null,
        dia_vencimento: 10, plan_id: null, desconto_especial_centavos: 0, cortesia: false,
        seller_name: null, preferred_payment_method: null, pop_name: null, cancelled_at: null, cancel_reason: null,
      });
    }
  }, [customer, open]);

  const cpfClean = form.cpf.replace(/\D/g, "");
  const cpfInvalid = useMemo(() => cpfClean.length === 11 && !isValidCPF(cpfClean), [cpfClean]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cpfClean.length !== 11 || !isValidCPF(cpfClean)) {
      toast.error("CPF inválido. Verifique os dígitos.");
      return;
    }
    setSaving(true);
    const phoneDigits = form.telefone ? form.telefone.replace(/\D/g, "") : "";
    const data = { ...form, cpf: cpfClean, telefone: phoneDigits || null };

    let success = false;
    if (customer && onUpdate) {
      success = await onUpdate(customer.id, data);
    } else {
      success = await onSave(data as CustomerInput);
    }
    setSaving(false);
    if (success) onOpenChange(false);
  };

  const handleSaveAndSend = async () => {
    if (!customer || !onUpdate) return;
    if (cpfClean.length !== 11 || !isValidCPF(cpfClean)) {
      toast.error("CPF inválido. Verifique os dígitos.");
      return;
    }
    setSendingMikrotik(true);
    try {
      const phoneDigits = form.telefone ? form.telefone.replace(/\D/g, "") : "";
      const ok = await onUpdate(customer.id, { ...form, cpf: cpfClean, telefone: phoneDigits || null });
      if (!ok) return;
      const { data, error } = await supabase.functions.invoke("mikrotik-customer", {
        body: { customer_id: customer.id, action: "sync" },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(data.message || "Enviado ao Mikrotik");
        onOpenChange(false);
      } else {
        toast.error(data?.error || "Falha ao enviar ao Mikrotik");
      }
    } catch (e: any) {
      toast.error(e.message || "Erro ao comunicar com o Mikrotik");
    } finally {
      setSendingMikrotik(false);
    }
  };


  const activePlans = plans.filter(p => p.ativo);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{customer ? "Editar Cliente" : "Novo Cliente"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="nome">Nome completo *</Label>
              <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required maxLength={100} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cpf">CPF *</Label>
              <Input id="cpf" value={form.cpf} onChange={(e) => setForm({ ...form, cpf: formatCPF(e.target.value) })} placeholder="000.000.000-00" required maxLength={14} className={cpfInvalid ? "border-destructive" : ""} />
              {cpfInvalid && (
                <p className="text-xs text-destructive flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" /> CPF inválido
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-mail *</Label>
              <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required maxLength={255} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="telefone">Telefone</Label>
              <Input id="telefone" value={form.telefone || ""} onChange={(e) => setForm({ ...form, telefone: formatPhone(e.target.value) })} placeholder="(00) 00000-0000" maxLength={15} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="usuario_pppoe">Usuário PPPoE *</Label>
              <Input id="usuario_pppoe" value={form.usuario_pppoe} onChange={(e) => setForm({ ...form, usuario_pppoe: e.target.value })} required maxLength={50} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="senha_pppoe">Senha PPPoE *</Label>
              <Input id="senha_pppoe" value={form.senha_pppoe} onChange={(e) => setForm({ ...form, senha_pppoe: e.target.value })} required maxLength={50} />
            </div>
          </div>

          {/* Faturamento */}
          <div className="border-t pt-4">
            <p className="text-sm font-medium mb-3 text-muted-foreground">Faturamento</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="plan_id">Plano</Label>
                <Select
                  value={form.plan_id || "none"}
                  onValueChange={(v) => setForm({ ...form, plan_id: v === "none" ? null : v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um plano" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {activePlans.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.nome} — {formatCurrency(p.valor_centavos)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="dia_vencimento">Dia de vencimento</Label>
                <Select
                  value={String(form.dia_vencimento)}
                  onValueChange={(v) => setForm({ ...form, dia_vencimento: Number(v) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 28 }, (_, i) => i + 1).map((d) => (
                      <SelectItem key={d} value={String(d)}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="desconto_especial">Desconto especial (pagamento antecipado)</Label>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">R$</span>
                  <Input
                    id="desconto_especial"
                    type="number"
                    min={0}
                    step={0.01}
                    value={(form.desconto_especial_centavos / 100).toFixed(2)}
                    onChange={(e) => setForm({ ...form, desconto_especial_centavos: Math.round(Number(e.target.value) * 100) })}
                    placeholder="0.00"
                  />
                </div>
                <p className="text-xs text-muted-foreground">Desconto adicional ao do plano para este cliente</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="seller_name">Vendedor</Label>
                <Input id="seller_name" value={form.seller_name || ""} onChange={(e) => setForm({ ...form, seller_name: e.target.value || null })} placeholder="Nome do vendedor" />
              </div>
              <div className="space-y-2">
                <Label>Forma de pagamento</Label>
                <Select value={form.preferred_payment_method || "none"} onValueChange={(v) => setForm({ ...form, preferred_payment_method: v === "none" ? null : v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Não informado</SelectItem><SelectItem value="pix">PIX</SelectItem><SelectItem value="boleto">Boleto</SelectItem><SelectItem value="card">Cartão</SelectItem><SelectItem value="cash">Dinheiro</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="pop_name">Concentrador / POP</Label>
                <Input id="pop_name" value={form.pop_name || ""} onChange={(e) => setForm({ ...form, pop_name: e.target.value || null })} placeholder="Ex.: POP Centro" />
              </div>
              <div className="flex items-center justify-between sm:col-span-2 rounded-lg border p-3 bg-muted/30">
                <div>
                  <Label htmlFor="cortesia" className="text-sm font-medium">Cortesia</Label>
                  <p className="text-xs text-muted-foreground">Cliente cortesia não gera boleto</p>
                </div>
                <Switch
                  id="cortesia"
                  checked={form.cortesia}
                  onCheckedChange={(checked) => setForm({ ...form, cortesia: checked })}
                />
              </div>
            </div>
          </div>

          {/* Endereço */}
          <div className="border-t pt-4">
            <p className="text-sm font-medium mb-3 text-muted-foreground">Endereço</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="rua">Rua</Label>
                <Input id="rua" value={form.rua || ""} onChange={(e) => setForm({ ...form, rua: e.target.value || null })} maxLength={200} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="numero">Número</Label>
                <Input id="numero" value={form.numero || ""} onChange={(e) => setForm({ ...form, numero: e.target.value || null })} maxLength={20} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="complemento">Complemento</Label>
                <Input id="complemento" value={form.complemento || ""} onChange={(e) => setForm({ ...form, complemento: e.target.value || null })} maxLength={100} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bairro">Bairro</Label>
                <Input id="bairro" value={form.bairro || ""} onChange={(e) => setForm({ ...form, bairro: e.target.value || null })} maxLength={100} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cidade">Cidade</Label>
                <Input id="cidade" value={form.cidade || ""} onChange={(e) => setForm({ ...form, cidade: e.target.value || null })} maxLength={100} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="estado">Estado</Label>
                <Input id="estado" value={form.estado || ""} onChange={(e) => setForm({ ...form, estado: e.target.value.toUpperCase() || null })} placeholder="UF" maxLength={2} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cep">CEP</Label>
                <Input id="cep" value={form.cep || ""} onChange={(e) => setForm({ ...form, cep: formatCEP(e.target.value) })} placeholder="00000-000" maxLength={9} />
              </div>
            </div>
          </div>

          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            {customer && (
              <Button type="button" variant="secondary" disabled={saving || sendingMikrotik} onClick={handleSaveAndSend}>
                {sendingMikrotik ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                Salvar e enviar ao Mikrotik
              </Button>
            )}
            <Button type="submit" disabled={saving || sendingMikrotik}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {customer ? "Salvar" : "Cadastrar"}
            </Button>
          </DialogFooter>

        </form>
      </DialogContent>
    </Dialog>
  );
}
